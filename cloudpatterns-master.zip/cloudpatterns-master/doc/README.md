Cloud based application development has become one of the most preferred ways to build software on the internet. It comes as no surprise due to it's numerous advantages. This guide will show you a number of ways you can apply proven cloud based patterns in  development.

Reference
http://en.clouddesignpattern.org/index.php/Main_Page

http://www.cloudcomputingpatterns.org/

http://cloudpatterns.org/
